package org.formation.dto;

public record CoffeeDto(Long id, String name) {

}
